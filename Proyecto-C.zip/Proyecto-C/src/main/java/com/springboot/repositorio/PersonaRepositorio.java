package com.springboot.repositorio;

import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;

import com.springboot.entidad.Persona;

@Repository
public interface PersonaRepositorio extends CrudRepository<Persona, Long>{

}
