package com.springboot.repositorio;

import org.springframework.data.repository.CrudRepository;

import com.springboot.entidad.Domicilio;

public interface DomicilioRepositorio extends CrudRepository<Domicilio, Long> {

}
