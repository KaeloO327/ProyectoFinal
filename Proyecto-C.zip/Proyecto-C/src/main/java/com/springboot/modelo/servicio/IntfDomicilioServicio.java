package com.springboot.modelo.servicio;

import java.util.List;

import com.springboot.entidad.Domicilio;

public interface IntfDomicilioServicio {
	
	List<Domicilio> listaDomicilio(); 
}
