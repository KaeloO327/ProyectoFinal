package com.springboot.modelo.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.clientapp.models.entity.Domicilio;
import com.springboot.clientapp.models.repository.DomicilioRepository;
import com.springboot.repositorio.DomicilioRepositorio;

@Service
public class DomicilioServioImpl implements IntfDomicilioServicio {
	
	@Autowired
	private DomicilioRepositorio domicilioRepositorio;
	
	@Override
	public List<Domicilio> listaDomicilio() {
		// TODO Auto-generated method stub
		return (List<Domicilio>) domicilioRepositorio).findAll();
	}

}
