package com.springboot.modelo.servicio;

import java.util.List;

import com.springboot.entidad.Cliente;
import com.springboot.entidad.Persona;
public interface IntfPersonaServicio {
	
	public List<Persona> listarTodos();
	public void guardar (Persona persona);
	public Persona buscarPorId(Long id);
	public void eliminar(Long id);
}
