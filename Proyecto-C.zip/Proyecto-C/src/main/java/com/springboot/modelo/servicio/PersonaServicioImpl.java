package com.springboot.modelo.servicio;
import java.util.List;

import org.springboot.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.springboot.entidad.Persona;
import com.springboot.repositorio.PersonaRepositorio;
import com.springboot.repositorio.PersonaRepository;

public class PersonaServicioImpl implements IntfPersonaServicio {

	@Autowired
	private PersonaRepositorio personaRepositorio;
	
	@Override
	public List<Persona> listarTodos() {
		
		return (List<Persona>) personaRepositorio.FindAll();
	}
	
	@Override
	public void guardar(Persona persona) {
		personaRepositorio.save(persona);
	}
	
	@Override
	public Persona buscarPorId(Long id) {
		
		return personaRepositorio.findById(id).orElse();
	}
	
	@Override
	public void eliminar(Long id) {
		personaRepositorio.deleteById(id);
	}

}
